<!DOCTYPE html>

<html lang="en">
	<head>
		<title>Cars We Provide</title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="css/touchTouch.css">
		<link rel="stylesheet" href="css/style.css">
		
		<script src="js/jquery.js"></script>
		<script src="js/jquery-migrate-1.2.1.js"></script>
		<script src="js/script.js"></script>
		<script src="js/superfish.js"></script>
		<script src="js/jquery.ui.totop.js"></script>
		<script src="js/jquery.equalheights.js"></script>
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script src="js/touchTouch.jquery.js"></script>
		
		<script>
			$(document).ready
			(
				function()
				{
				$().UItoTop({ easingType: 'easeOutQuart' });
				$('.gallery a.gal').touchTouch();
				}
			);
		</script>
		
	</head>
	
	<body class="" id="top">

	<div class="main">

<!--==============================header=================================-->
			<header>
				<div class="menu_block ">
					<div class="container_12">
						<div class="grid_12">
							<nav class="horizontal-nav full-width horizontalNav-notprocessed">
								<ul class="sf-menu">
									<li><a href="index.php">HOME</a></li>
									
									<li class="current"><a href="car.php">RIDES</a></li>
									<li><a href="result.php">BOOK A RIDE</a></li>
									<li><a href="contact.php">ABOUT US</a></li>
								</ul>
							</nav>
							<div class="clear"></div>
						</div>
						<div class="clear"></div>
					</div>
				</div>
				
				<div class="container_12">
					<div class="grid_12">
						<h1>
							<a href="index.html">
								<img src="images/logo.png" alt="Your Happy Family">
							</a>
						</h1>
					</div>
				</div>
				
				<div class="clear"></div>
			</header>

<!--==============================Content=================================-->
			<div class="content">
				<div class="container_12">
					<div class="grid_12">
						<h3>Economy</h3>
					</div>
					
					<div class="clear"></div>
					<div class="gallery">
						<div class="grid_4"><a href="images/big1.jpg" class="gal"><img src="images/1.jpg" alt=""></a></div>
						<div class="grid_4"><a href="images/big2.jpg" class="gal"><img src="images/2.jpg" alt=""></a></div>
						<div class="grid_4"><a href="images/big3.jpg" class="gal"><img src="images/3.jpg" alt=""></a></div>
					</div>
					
					<div class="grid_12">
						<h3>Standard</h3>
					</div>
					
					<div class="clear"></div>
					<div class="gallery">
						<div class="grid_4"><a href="images/big4.jpg" class="gal"><img src="images/11.jpg" alt=""></a></div>
						<div class="grid_4"><a href="images/big5.jpg" class="gal"><img src="images/22.jpg" alt=""></a></div>
						<div class="grid_4"><a href="images/big6.jpg" class="gal"><img src="images/33.jpg" alt=""></a></div>
					</div>
					
					<div class="grid_12">
						<h3>Luxuary</h3>
					</div>
					
					<div class="clear"></div>
					<div class="gallery">
						<div class="grid_4"><a href="images/big7.jpg" class="gal"><img src="images/page3_img7.jpg" alt=""></a></div>
						<div class="grid_4"><a href="images/big8.jpg" class="gal"><img src="images/page3_img8.jpg" alt=""></a></div>
						<div class="grid_4"><a href="images/big9.jpg" class="gal"><img src="images/page3_img9.jpg" alt=""></a></div>
					</div>
					
					<div class="clear"></div>
				</div>
			</div>
		</div>
<!--==============================footer=================================-->
		<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="f_phone"><span>Call Us:</span> 1800 200 200</div>
					<div class="socials">
						<a href="https://twitter.com/?lang=en" class="fa fa-twitter"></a>
						<a href="https://www.facebook.com/" class="fa fa-facebook"></a>
						<a href="https://accounts.google.com/" class="fa fa-google-plus"></a>
						<a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a>
					</div>
					<div class="copy">
						<div class="st1">
						<div class="brand">LIFT<span class="color1">ME</span></div>
						&copy; 2021| <a href="https://policies.google.com/privacy?hl=en-US">Privacy Policy</a> </div> All Right Reserved
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</footer>
	</body>
</html>