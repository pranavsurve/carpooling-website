
 .fade
 {
	 opacity:0;
     -webkit-transition:opacity .15s linear;
     -o-transition:opacity .15s linear;
     transition:opacity .15s linear;
 }
 .fade.in{opacity:1}


.alert{
	padding:15px;
	margin-bottom:20px;
	border:1px solid transparent;
	border-radius:4px
	}

.alert-dismissable,.alert-dismissible
{
padding-right:35px;
display:inline-block;
background-color:#F96E67;
color:#D4130A;
border-color:#E5300C;
margin:10px; }.alert-dismissable 

.close{
	position:relative;
	top:-2px;right:-21px;
	color:inherit
	}


.alert-success{
	color:#3c763d;
	background-color:#CFF59E ;
	border-color:#d6e9c6;
	display:inline-block;
	margin:10px;
	}
.alert-success hr{
	border-top-color:#c9e2b3
	}

 
 
 

 .close{float:right;font-size:21px;font-weight:700;
 line-height:1;color:#000;text-shadow:0 1px 0 #fff;
 filter:alpha(opacity=20);opacity:.2}
 
 
 .close:focus,.close:hover{color:#000;text-decoration:none;cursor:pointer;filter:alpha(opacity=50);opacity:.5}
 
 