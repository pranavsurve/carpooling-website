<?php

include("connection/connect.php");
error_reporting(0);

$book = $_GET['book'];

if(isset($_POST['submit']))
{
	$pick = $_POST['pick'];   
	$drop = $_POST['drop'];
	$phone = $_POST['phone'];
	$fname = $_POST['fname'];
	$fmid = $_POST['fmid'];
	$flast = $_POST['flast'];
	$zipcode = $_POST['zipcode'];
	$address = $_POST['address'];
	$cardno = $_POST['cardno'];
	$brand = $_POST['brand'];
	$date = $_POST['date'];
	$year = $_POST['year'];
	$month = $_POST['month'];
	$text = $_POST['text'];

    if($pick==' '|| $drop==' ' || $phone==' '|| $fname==' '|| $fmid==' '|| $flast==' '|| $zipcode==' '|| $address==' '|| $cardno==' '|| $brand==''|| $date==' '|| $year==' '|| $month==' '|| $text==' ' )
	{
		echo '<div class="alert alert-dismissable fade in">';
        echo	'<a href="#"  data-dismiss="alert" ></a>';				
		echo ' All Text Field must be required!';
		echo  	'</div>';	
	}
	
	else
	{
		$sql = "INSERT INTO personal(pickup,dropoff,phone,first,mid,last,cod,address,cardno,cardbrand,ed,ey,em,message) VALUES ('$pick', '$drop','$phone','$fname','$fmid','$flast','$zipcode','$address','$cardno','$brand','$date','$year','$month','$text')";
		mysqli_query($db, $sql);
	
		echo '<div class="alert alert-success alert-dismissable fade in">';
		echo	'<a href="#" data-dismiss="alert" ></a>';
		echo 'Your Booking submit Successfully. Details are send to your Registered E-mail Address.';
		echo  	'</div>';
	}
}

$sql="select * from admin where v_id='$book'";
$result=mysqli_query($db,$sql);
$row=mysqli_fetch_array($result);
						
	$id =  $row['v_id'];
	$cimage =  $row['cimage'];
	$cname =  $row['cname'];
	$seat =  $row['seat'];
	$price =  $row['price'];
	$ctext =  $row['ctext'];
	
	$air_c =  $row['air_c'];
	$fuel =  $row['fuel'];
	$gps =  $row['gps'];
	$safety =  $row['safety'];
	$km =  $row['km'];
?>


<!DOCTYPE html>

<html lang="en">
	<head>
		<title>Booking Page</title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="css/form.css">
		<link rel="stylesheet" href="css/style.css">
		
		<link rel="stylesheet" type="text/css" href="css/popup.php">
	</head>
	
	<body class="" id="top">
	
		<div class="main">
<!--==============================header=================================-->
			<header>
				<div class="menu_block ">
					<div class="container_12">
						<div class="grid_12">
							<nav class="horizontal-nav full-width horizontalNav-notprocessed">
								<ul class="sf-menu">
									<li><a href="index.php">HOME</a></li>
								
									<li><a href="car.php">RIDES</a></li>
									<li><a href="result.php">BOOK A RIDE</a></li>
									<li ><a href="contact.php">ABOUT US</a></li>
								</ul>
							</nav>
							<div class="clear"></div>
						</div>
						<div class="clear"></div>
					</div>
				</div>
				
				<div class="container_12">
					<div class="grid_12">
						<h1>
							<a href="index.html">
								<img src="images/logo.png" alt="Your Happy Family">
							</a>
						</h1>
					</div>
				</div>
				
				<div class="clear"></div>
			</header>
<!--==============================Content=================================-->
			<div class="content">
				<div class="container_12">
					<div class="grid_12">
						
						<center><h3>BOOK NOW!</h3></center>
<?php						

	echo		'<div class="map">';
	echo			'<figure>';
							
    echo			"<div class='' ><a href='admin/images/".$cimage." ' class='gal'><img src='admin/images/".$cimage." ' style='height:400px;width:1900px;'></a></div>";
					
	echo			'</figure>';
	echo			'</div>';
	echo		'</div>';
					
	echo		'<div class="grid_5">';
	echo		'<h3>Taxi Info</h3>';
	echo		'<div class="map">';
	echo			'<div class="text1 color2"><span style="font-size:40px;">'.$cname.'</span></div>';
	echo			'<div class="text1 color2">Price: <span style="color:red">'.$price.'/-</span></div>';
	echo				'<p>'.$ctext.'</p>';
	
	echo				'<address>';
	echo				'<dl>';
	
	echo			'<dd><span  style="font-size:20px;">Passenger Seats</span><span style="color:;font-size:18px;margin-left:10px;"> :'.$seat.'</span></dd>';
	echo				'<dd><span  style="font-size:20px;">Air Conditioner</span><span style="color:;font-size:18px;margin-left:20px;"> :'.$air_c.'</span></dd>';
	echo				'<dd><span  style="font-size:20px;">Fuel Type </span><span style="color:;font-size:18px;margin-left:72px;">:'.$fuel.'</span> </dd>';
	echo				'<dd><span  style="font-size:20px;">GPS</span><span style="color:;font-size:18px;margin-left:123px;">  :'.$gps.'</span></dd>';
	echo				'<dd><span  style="font-size:20px;">safety</span> <span style="color:;font-size:18px;margin-left:101px;"> :'.$safety.'</span></dd>';
	echo				'<dd><span  style="font-size:20px;">Km/Rs</span><span style="color:;font-size:18px;margin-left:100px;"> :'.$km.'</span></dd>';
	echo			'</dl>';
	echo			'</address>';
	echo		'	</div>';
	echo			'</div>';
?>				
	
	<div class="grid_6 prefix_1">
		<h3>Ride Details:</h3>
						
		<form id="form" action=" " method="post">
			<div class="success_wrapper">
				<div class="success-message">Details Submitted Successfully!</div>
			</div>
			
			<b>Pickup Location:</b><br>
			<label class="name" >
				<select name='pick' style='height:30px;width:170px;border:1px solid #fff;'>
					<option selected="selected" disabled="disabled">Start Point</option>
					<option value='JALANDHAR'>PUNE</option>
					<option value='MOGA'>Mumbai</option>
					<option value='FARIDKOT'>Nashik</option>
				</select>           
			</label>
			
			<br><br><b>Destination:</b><br>
			<label class="name" >
				<select name='drop'	style='height:30px;width:170px;border:1px solid #fff;'>
					<option selected="selected" disabled="disabled">End Point</option>
                    <option value='JALANDHAR'>Pachgani</option>
                    <option value='MOGA'>Nagpur</option>
                    <option value='FARIDKOT'>Satara</option>
				</select>           
							
				<span class="error-message">Please Enter a Valid Name!</span>
			</label>
			
			<br><br><b>Contact No:</b><br>
			<label class="phone">
				<input name='phone' type="text" placeholder="Enter Number" />
				<span class="error-message">Please Enter a Valid Number!</span>
			</label>
			<br>
			
			<div class="clear"></div>
			<h3>Billing Details</h3>
			
			<b>First Name:</b><br>
			<label class="name">
				<input name='fname'  type="text" placeholder="Enter First Name" />
			</label>
			
			<br><br><b>Middle Name:</b><br>
			<label class="name">
				<input name='fmid' type="text" placeholder="Enter Middle Name" />
			</label>
			
			<br><br><b>Last Name:</b><br>
			<label class="name">
				<input name='flast' type="text" placeholder="Enter Last Name" />
			</label>
			
			<br><br><b>Pin Code:</b><br>
			<div class="clear"></div>
				<label class="name">
					<input name='zipcode' type="text" placeholder="Enter Pin Code" />
				</label>
				
				<br><br><b>Address:</b><br>
				<label class="name">
					<textarea name='address' type="text" placeholder="Enter Address" /></textarea>
				</label>
							
				<div class="clear"></div>
					<br><h3>Credit Card/Debit Card Details</h3>
					
					<b>Card Number:</b><br>
					<label class="name">
						<input name='cardno' type="text" placeholder="Enter Card No." />
					</label>
					
					<br><br><b>Card Type:</b><br>
					<label  class="name" >
						<select name='brand' style='height:30px;width:170px;border:1px solid #fff;'>
							<option selected="selected" disabled="disabled">Select Type</option>
                            <option value='Master Card'>Master Card</option>
                            <option value='Visa'>Visa</option>
                            <option value='Discover'>Discover</option>
							<option value='American Express'>American Express</option>
						</select>           
					</label>
					
					<br><br><b>Expiry Date:</b><br>
					<div class="clear"></div>
						<label class="name">
							<select name='month' style='height:30px;width:170px;border:1px solid #fff;'>
								<option selected="selected" disabled="disabled">Select Month</option>
                                <option value='01 '>01</option>
								<option value='02 '>02</option>
								<option value='03 '>03</option>
								<option value='04 '>04</option>
								<option value='05 '>05</option>
								<option value='06 '>06</option>
								<option value='07 '>07</option>
								<option value='08 '>08</option>
								<option value='09 '>09</option>
								<option value='10 '>10</option>
								<option value='11 '>11</option>
								<option value='12 '>12</option>
                            </select>   
						</label>
						
						<label class="name">
							<select name='year'	style='height:30px;width:170px;border:1px solid #fff;' >
								<option selected="selected" disabled="disabled">Select Year</option>
                                <option value='2018 '>2021</option>
								<option value='2017 '>2022</option>
								<option value='2016 '>2023</option>
								<option value='2015 '>2024</option>
								<option value='2014 '>2025</option>
								<option value='2013 '>2026</option>
								<option value='2012 '>2027</option>
								<option value='2011 '>2028</option>
								<option value='2010 '>2029</option>
								<option value='2009 '>2030</option>
                            </select>   
						</label>
							
						<input id='ds' type='submit' name='submit'  value='submit' />
		</form>
	</div>
	
	<div class="clear"></div>
				</div>
			</div>
		</div>
<!--==============================footer=================================-->
		<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="f_phone"><span>Call Us:</span> 1800 200 200</div>
					<div class="socials">
						<a href="https://twitter.com/?lang=en" class="fa fa-twitter"></a>
						<a href="https://www.facebook.com/" class="fa fa-facebook"></a>
						<a href="https://accounts.google.com/" class="fa fa-google-plus"></a>
						<a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a>
					</div>
					<div class="copy">
						<div class="st1">
						<div class="brand">LIFT<span class="color1">ME</span></div>
						&copy; 2021| <a href="https://policies.google.com/privacy?hl=en-US">Privacy Policy</a> </div> All Right Reserved
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</footer>
	</body>
</html>